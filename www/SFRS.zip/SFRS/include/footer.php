<?php
/**
 * Created by PhpStorm.
 * User: kevin
 * Date: 10/8/2016
 * Time: 10:08 PM
 */

?>

</div>

<!-- Latest compiled and minified JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>

<!-- Metis Menu Plugin JavaScript -->
<script src="/sfrs/js/metisMenu.min.js"></script>
<!-- Custom Theme JavaScript -->
<script src="/sfrs/js/sb-admin-2.min.js"></script>


</body>
</html>
