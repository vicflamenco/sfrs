<?php

namespace Kendo\Dataviz\UI;

class ChartAxisDefaults extends \Kendo\SerializableObject {
//>> Properties

//<< Properties
}

?>
