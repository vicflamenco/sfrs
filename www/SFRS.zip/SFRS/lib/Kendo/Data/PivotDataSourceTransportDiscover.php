<?php
namespace Kendo\Data;

class PivotDataSourceTransportDiscover extends \Kendo\Data\DataSourceTransportRead {
//>> Properties

//<< Properties
}

?>
